console.log("Script running");

document.querySelector('.cross').style.display = 'none';
document.querySelector('.icons').addEventListener("click", () => {
    document.querySelector('.sidebar').classList.toggle('sidebarGo');
    if (document.querySelector('.sidebar').classList.contains('sidebarGo')) {
        document.querySelector('.hamburger').style.display = 'inline';
        document.querySelector('.cross').style.display = 'none';
    } else {
        setTimeout(()=>{
            document.querySelector('.cross').style.display = 'inline';

        },300);
        document.querySelector('.hamburger').style.display = 'none';

    }
});

function funn(){
    window.location.href = 'contact.html';
}
 function downloadFile() {
            const link = document.createElement('a');
            link.href = '/cv.txt'; // Replace with the path to your file
            link.download = 'cv.txt'; // Replace with the desired file name
            link.click();
        }